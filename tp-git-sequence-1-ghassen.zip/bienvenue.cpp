#include <iostream>

// TODO Indiquer ce que fait le programme
int main()
{
    std::cout << "Bienvenue le monde !" << std::endl;
    // TODO Afficher un message de bienvenue
    return 0;
}
